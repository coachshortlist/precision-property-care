import { defineConfig } from 'astro/config';

// Netlify sets URL automatically at build time. Set SITE_URL once the real domain is connected.
export default defineConfig({
  site: process.env.SITE_URL || process.env.URL || 'http://localhost:4321',
  trailingSlash: 'always',
  build: { format: 'directory' }
});
